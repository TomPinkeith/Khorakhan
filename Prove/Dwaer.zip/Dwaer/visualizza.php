<html>
  <head>
    <title>
      Forum
    </title>
  </head>
  <body>
    <center>
      <? include "messaggi.txt"; ?>
    </center>
  </body>
</html>