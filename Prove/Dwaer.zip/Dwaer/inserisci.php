<?
  $testo = $_POST['commento'];
  $autore = $_POST['autore'];
  $url = $_POST['url'];

  $toins = "$autore scrive:<br> $testo";

  if ($url != "") {
    $toins = $toins."<br> <a href=\"$url\">$url</a><hr>\n";
  } else {
    $toins = $toins."<hr>\n";
  }

  $file = fopen("messaggi.txt", "a");
  fwrite($file, $toins);
?>